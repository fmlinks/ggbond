from setuptools import setup, find_packages

setup(
    name='ggbond',
    version='0.1',
    author='FMlin',
    author_email='sdulinfm@gmail.com',
    description='medical image segmentation',
    packages=find_packages(),
)